<?php $__env->startSection('content'); ?>
    <section class="container">
        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="my-3 nav-link font-weight-bold"><a href="<?php echo e(route('news.category.name', $item['slug'])); ?>"><?php echo e($item['title']); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-8.vagrant/resources/views/news/category.blade.php ENDPATH**/ ?>