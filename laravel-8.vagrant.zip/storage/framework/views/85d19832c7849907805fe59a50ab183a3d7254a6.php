<?php $__env->startSection('content'); ?>

<section class="container">
    <h1 class="font-weight-bold">News of <?php echo e($category); ?></h1>
    <hr>
    <?php if($news): ?>
        <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <ul>
                <h3 class="font-weight-bold"><?php echo e($item['title']); ?></h3>
                <?php if(!$item['isPrivate']): ?>
                    <li class="my-3 nav-link font-weight-bold">
                        <a href="<?php echo e(route('news.category.post', $item['id'])); ?>">Подробнее..</a>
                    </li>
                <?php endif; ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            Нет новостей
        <?php endif; ?>
    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-8.vagrant/resources/views/news/category-news.blade.php ENDPATH**/ ?>