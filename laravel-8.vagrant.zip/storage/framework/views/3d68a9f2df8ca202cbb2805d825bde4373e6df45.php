<?php $__env->startSection('content'); ?>
    <section class="container">
        <ul>
            <li class="my-3 nav-link font-weight-bold"><a href="<?=route('#', ['id'=> 1])?>">Post-1</a></li>
            <li class="my-3 nav-link font-weight-bold"><a href="<?=route('#', ['id'=> 2])?>">Post-2</a></li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-8.vagrant/resources/views/news/news.blade.php ENDPATH**/ ?>