<?php $__env->startSection('content'); ?>
    <section class="container">
        <h2><?php echo e($news['title']); ?></h2>
        <p><?php echo e($news['text']); ?></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-8.vagrant/resources/views/news/post.blade.php ENDPATH**/ ?>