<?php $__env->startSection('content'); ?>
    <section class="container">
        <h1>About</h1>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel-8.vagrant/resources/views/pages/about.blade.php ENDPATH**/ ?>