@extends('layout.app')
@section('content')
    <section class="container">
        <h1>Home</h1>
    </section>
@endsection
